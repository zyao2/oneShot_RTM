%Time domain finite difference solver to acoustic wave equation

%velocity model
nz=81;nx=201;
vel=zeros(nz,nx);
vel(1:30,:)=1000;
vel(31:60,:)=1200;
vel(61:end,:)=1500;

%source and receiver location;
dx=5;dz=5;
sx=100*dx;xz=0;
recx=(0:2:(nx-1))*dx; recz=zeros(size(gx));

%FD parameters;
nbc=20; nt=2001; dt=0.0005;

%source wavelet;
freq=25; s=ricker(freq,dt);

%Plot the velocity and wavelet;

figure(1);set(gcf,'position',[0 0 800 400]);subplot(221);imagesc(x,z,vel);colorbar;
xlabel('X (m)'); ylabel('Z (m)'); title('velocity');
figure(1);subplot(222);plot((0:numel(s)-1)*dt,s);
xlabel('Time (s)'); ylabel('Amplitude');title('wavelet');

%Run the modeling code, watch the movie of wave propagation, and plot the seismic data;

tic;
seis=forward(vel,nbc,dx,nt,dt,s,sx,sz,recx,recz);
toc;
